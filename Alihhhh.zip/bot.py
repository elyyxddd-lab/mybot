import logging
from aiogram import Bot, Dispatcher, executor, types

API_TOKEN = "7087558723:AAEAVJvaxNFH4EthjnTpt9jm5pCv8AnQ-Cs"

# إعداد اللوجات
logging.basicConfig(level=logging.INFO)

# تهيئة البوت
bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot)

# أوامر البداية
@dp.message_handler(commands=['start'])
async def start_command(message: types.Message):
    await message.reply("🚀 البوت شغال!")

if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)
